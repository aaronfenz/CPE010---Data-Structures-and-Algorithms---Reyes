#include <iostream>
#include <iomanip>
using namespace std;

// Function to compute total price and change
void ComputeTransaction(float item1, float item2, float item3, float payment,
                        float &total, float &change)
{
    total = item1 + item2 + item3;
    change = payment - total;
}

int main()
{
    float item1, item2, item3;
    float payment, total, change;
    char choice = 'Y';

    while (choice == 'Y' || choice == 'y')
    {
        cout << "\n=========================================\n";
        cout << "          CASHIERING SYSTEM\n";
        cout << "=========================================\n";

        cout << "Enter price of Item 1: ";
        cin >> item1;

        cout << "Enter price of Item 2: ";
        cin >> item2;

        cout << "Enter price of Item 3: ";
        cin >> item3;

        cout << "Enter Payment: ";
        cin >> payment;

        ComputeTransaction(item1, item2, item3, payment, total, change);

        if (payment < total)
        {
            cout << "\n=========================================\n";
            cout << "        INSUFFICIENT PAYMENT!\n";
            cout << " Transaction cannot be completed.\n";
            cout << "=========================================\n";
            cout << "\nCashiering System Ended." << endl;

            return 0;   // Ends the program immediately if the money is insufficient
        }

        cout << fixed << setprecision(2);

        cout << "\n=========================================\n";
        cout << "               SALES RECEIPT\n";
        cout << "=========================================\n";
        cout << left << setw(20) << "Item 1:" << "PHP " << item1 << endl;
        cout << left << setw(20) << "Item 2:" << "PHP " << item2 << endl;
        cout << left << setw(20) << "Item 3:" << "PHP " << item3 << endl;
        cout << "-----------------------------------------\n";
        cout << left << setw(20) << "Total Price:" << "PHP " << total << endl;
        cout << left << setw(20) << "Payment:" << "PHP " << payment << endl;
        cout << left << setw(20) << "Change:" << "PHP " << change << endl;
        cout << "=========================================\n";
        cout << "     THANK YOU FOR YOUR PURCHASE!\n";
        cout << "=========================================\n";

        cout << "\nDo you want another transaction? (Y/N): ";
        cin >> choice;
    }

    cout << "\nCashiering System Ended." << endl;

    return 0;
}