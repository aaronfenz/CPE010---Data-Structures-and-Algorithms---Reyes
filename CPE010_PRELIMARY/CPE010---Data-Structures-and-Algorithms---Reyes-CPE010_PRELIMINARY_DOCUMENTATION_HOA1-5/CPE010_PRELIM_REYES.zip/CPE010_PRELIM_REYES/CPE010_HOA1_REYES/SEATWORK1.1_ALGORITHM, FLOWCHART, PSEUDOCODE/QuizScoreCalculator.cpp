#include <iostream>
using namespace std;

// Function to compute total and average
void ComputeQuiz(float q1, float q2, float q3, float &total, float &average)
{
    total = q1 + q2 + q3;
    average = total / 3
}

int main(){

    float quiz1, quiz2, quiz3;
    float total, average;
    char choice = 'Y';

    while (choice == 'Y' || choice == 'y')
    {
        cout << "Enter Quiz 1: ";
        cin >> quiz1;

        cout << "Enter Quiz 2: ";
        cin >> quiz2;

        cout << "Enter Quiz 3: ";
        cin >> quiz3;

        ComputeQuiz(quiz1, quiz2, quiz3, total, average);

        cout << "\nTotal Quiz Score: " << total << endl;
        cout << "Average Quiz Score: " << average << endl;

        cout << "\nDo you want to enter another set of quiz scores? (Y/N): ";
        cin >> choice;
        cout << endl;
    }

    cout << "Program Ended." << endl;

    return 0;

}
